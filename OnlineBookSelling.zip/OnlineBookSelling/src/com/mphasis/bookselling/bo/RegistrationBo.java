package com.mphasis.bookselling.bo;

import java.util.List;

import com.mphasis.bookselling.bean.Registration;
import com.mphasis.bookselling.dao.RegistrationDao;
import com.mphasis.bookselling.dao.RegistrationDaoImpl;

public class RegistrationBo {

	public void create(Registration registration) {
		RegistrationDao registrationDao=new RegistrationDaoImpl();
	    registrationDao.create(registration);
		
	}

	public  List<Registration> read(int sno) {
		RegistrationDao registrationDao=new RegistrationDaoImpl();
		List<Registration> RegistrationList=registrationDao.read(sno);
		return RegistrationList;
	}
	
	public  void update (int sno,String emailid) {
		RegistrationDao registrationDao=new RegistrationDaoImpl();
		registrationDao.update(sno,emailid);
		
	}

	public   void delete(int sno) {
		RegistrationDao registrationDao=new RegistrationDaoImpl();
		registrationDao.delete(sno);
		
	}

}


