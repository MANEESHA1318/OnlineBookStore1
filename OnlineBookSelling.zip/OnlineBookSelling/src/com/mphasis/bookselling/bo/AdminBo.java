package com.mphasis.bookselling.bo;

import java.util.List;

import com.mphasis.bookselling.bean.Admin;
import com.mphasis.bookselling.dao.AdminDao;
import com.mphasis.bookselling.dao.AdminDaoImpl;

public class AdminBo {

	public void create(Admin admin) {
		AdminDao adminDao=new AdminDaoImpl();
	    adminDao.create(admin);
		
	}

	public  List<Admin> read(int userid) {
		AdminDao adminDao=new AdminDaoImpl();
		List<Admin> AdminList=adminDao .read(userid);
		return AdminList;
	}
	
	public  void update (int userid,String status) {
		AdminDao adminDao=new AdminDaoImpl();
		adminDao.update(userid,status);
		
	}

	public   void delete(int userid) {
		AdminDao adminDao=new AdminDaoImpl();
		adminDao.delete(userid);
		
	}

}


