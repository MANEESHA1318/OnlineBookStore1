package com.mphasis.bookselling.bo;

import java.util.List;

import com.mphasis.bookselling.bean.Books;
import com.mphasis.bookselling.dao.BooksDao;
import com.mphasis.bookselling.dao.BooksDaoImpl;

public class BooksBo {

	public void create(Books books) {
		BooksDao booksDao=new BooksDaoImpl();
	    booksDao.create(books);
		
	}

	public  List<Books> read(int bookid) {
		BooksDao booksDao=new BooksDaoImpl();
		List<Books> BooksList=booksDao.read(bookid);
		return BooksList;
	}
	
	public  void update (int bookid,String author) {
		BooksDao booksDao=new BooksDaoImpl();
		booksDao.update(bookid,author);
		
	}

	public   void delete(int bookid) {
		BooksDao bookDao=new BooksDaoImpl();
		bookDao.delete(bookid);
		
	}

}


