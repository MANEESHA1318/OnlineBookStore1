package com.mphasis.bookselling.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mphasis.bookselling.bean.Registration;
import com.mphasis.bookselling.util.DBHandler;

public class RegistrationDaoImpl implements RegistrationDao{
	private String sno;

	public void create(Registration r) {
		PreparedStatement ps = null;
		Connection conn = null;
		try {
			conn = DBHandler.getConnection();
			// conn.setAutoCommit(false);
			String query = "insert into registration(sno,Firstname,Lastname,emailid,phonenumber,gender,dob) values(?,?,?,?,?,?,?)";
			ps = conn.prepareStatement(query);
			ps.setInt(1, r.getSno());
			ps.setString(2, r.getFirstname());
			ps.setString(3, r.getlastname());
			ps.setString(4, r.getemailid());
			ps.setLong(5, r.getphonenumber());
			ps.setString(6, r.getgender());
			ps.setInt(7, r.getdob());
			int rows = ps.executeUpdate();
			System.out.println(rows + "row  inserted");
			// conn.commit();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
	}

	public List<Registration> read(int sno) {
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Registration> list = new ArrayList<>();
		Registration r = null;
		Connection conn = null;
		try {
			conn = DBHandler.getConnection();
			String query = "select * from registration where sno =?";
			ps = conn.prepareStatement(query);
			ps.setInt(1, sno);
			rs = ps.executeQuery();
			System.out.println("Registration Details" + sno);
			while (rs.next()) {
				r = new Registration();
				r.setSno(rs.getInt("sno"));
				r.setFirstname(rs.getString("firstname"));
				r.setLastname(rs.getString("lastname"));
				r.setphonenumber(rs.getInt("phonenumber"));
				r.setemailid(rs.getString("emailid"));
				r.setdob(rs.getInt("dob"));
				r.setgender(rs.getString("gender"));
				list.add(r);
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return list;
	}

	public void update(int sno, String emailid) {
		PreparedStatement ps = null;
		Connection conn = null;
		try {
			conn = DBHandler.getConnection();
			String query = "update Registration set emailid=? where sno=?";
			ps = conn.prepareStatement(query);
			ps.setString(1,emailid);
			ps.setInt(2, sno);
			int res = ps.executeUpdate();
			System.out.println(res + " row updated");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		finally {
			try {
				conn.close();
			} catch (SQLException e) {

				System.out.println(e.getMessage());
			}
		}
	}

	public void delete(int sno)  {
		PreparedStatement ps = null;
		Connection conn = null;
		try {
			conn = DBHandler.getConnection();
			String query = "delete from registration where sno=?";
			ps = conn.prepareStatement(query);
			ps.setInt(1, sno);
			int res = ps.executeUpdate();
			System.out.println(res + " row deleted");
		} catch (SQLException e) {

			System.out.println(e.getMessage());
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {

				System.out.println(e.getMessage());
			}
		}

	}
}
