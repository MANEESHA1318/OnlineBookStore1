package com.mphasis.bookselling.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mphasis.bookselling.bean.Books;
import com.mphasis.bookselling.util.DBHandler;

public class BooksDaoImpl implements BooksDao{
	private String bookname;

	public void create(Books b) {
		PreparedStatement ps = null;
		Connection conn = null;
		try {
			conn = DBHandler.getConnection();
			// conn.setAutoCommit(false);
			String query = "insert into books(bookname,bookid,author,price,quantity,addtocart) values(?,?,?,?,?,?)";
			ps = conn.prepareStatement(query);
			ps.setString(1, b.getBookname());
			ps.setInt(2, b.getBookid());
			ps.setString(3, b.getAuthor());
			ps.setInt(4, b.getPrice());
			ps.setInt(5, b.getQuantity());
			ps.setString(6,b. getAddtocart());
			
			int rows = ps.executeUpdate();
			System.out.println(rows + "Books Added into list");
			// conn.commit();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
	}

	public List<Books> read(int bookid) {
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Books> list = new ArrayList<>();
		Books b = null;
		Connection conn = null;
		try {
			conn = DBHandler.getConnection();
			String query = "select * from books where bookid =?";
			ps = conn.prepareStatement(query);
			ps.setInt(1, bookid);
			rs = ps.executeQuery();
			System.out.println("Registration Details" + bookid);
			while (rs.next()) {
				b = new Books();
				b.setBookname(rs.getString("bookname"));
				b.setBookid(rs.getInt("bookid"));
				b.setAuthor(rs.getString("author"));
				b.setPrice(rs.getInt("price"));
				b.setQuantity(rs.getInt("quantity"));
				b.setAddtocart(rs.getString("addtocart"));
				
				list.add(b);
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		return list;
	}

	public void update(int bookid, String bookname) {
		PreparedStatement ps = null;
		Connection conn = null;
		try {
			conn = DBHandler.getConnection();
			String query = "update Books set bookname=? where bookid=?";
			ps = conn.prepareStatement(query);
			ps.setString(1,bookname);
			ps.setInt(2, bookid);
			int res = ps.executeUpdate();
			System.out.println(res + "Book Author updated");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		finally {
			try {
				conn.close();
			} catch (SQLException e) {

				System.out.println(e.getMessage());
			}
		}
	}

	public void delete(int bookid)  {
		PreparedStatement ps = null;
		Connection conn = null;
		try {
			conn = DBHandler.getConnection();
			String query = "delete from books where bookid=?";
			ps = conn.prepareStatement(query);
			ps.setInt(1, bookid);
			int res = ps.executeUpdate();
			System.out.println(res + " Remove Books Successflly");
		} catch (SQLException e) {

			System.out.println(e.getMessage());
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {

				System.out.println(e.getMessage());
			}
		}

	}
}
