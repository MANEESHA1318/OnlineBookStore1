package com.mphasis.bookselling.dao;

import java.util.List;

import com.mphasis.bookselling.bean.Books;

public interface BooksDao {
	
	public void create(Books r);
	public List<Books> read(int bookid);
	public void update(int bookid, String bookname);
	public  void delete(int bookid);
}
