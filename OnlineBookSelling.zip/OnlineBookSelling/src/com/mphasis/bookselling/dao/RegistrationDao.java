package com.mphasis.bookselling.dao;

import java.util.List;

import com.mphasis.bookselling.bean.Registration;

public interface RegistrationDao {
	
	public void create(Registration r);
	public List<Registration> read(int sno);
	public void update(int sno, String emailid);
	public  void delete(int sno);
}
