package com.mphasis.bookselling.view;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.mphasis.bookselling.bean.Books;
import com.mphasis.bookselling.bo.BooksBo;

public class PreparedBk {
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		int bookid,price,quantity;
		
		String bookname,author,addtocart, choice;
		int ch;
		BooksBo booksBo = new BooksBo();
		List<Books> list = new ArrayList<>();
		do {
			System.out.println("CRUD Application");
			System.out.println("1.ADD BOOKS \n 2.VIEW BOOKS \n 3.UPDATEBOOKS \n 4.DELETE BOOKS");
			System.out.println("Enter choice");
			ch = scanner.nextInt();
		
			switch (ch) {
			case 1:
				System.out.println("Enter Book details bookname,bookid,author,price,quantity,addtocart");
				bookname = scanner.next();
				bookid = scanner.nextInt();
			    author = scanner.next();
			    price = scanner.nextInt();
			    quantity = scanner.nextInt();
			    addtocart = scanner.next();
			    
			    Books books = new Books();
			
				books.setBookname(bookname);
				books.setBookid(bookid);
				books.setAuthor(author);
			    books.setPrice(price);
			    books.setQuantity( quantity);
			    books.setAddtocart(addtocart);
			    
				booksBo.create(books);

				break;
			case 2:
				System.out.println("Enter bookid");
				bookid = scanner.nextInt();

				list = booksBo.read( bookid);
				list.forEach(b -> System.out.println(b));		

				break;

			case 3:
				System.out.println("Enter bookid and bookname to update");
				bookid = scanner.nextInt();
                author=scanner.next();
				booksBo.update(bookid,author);

				break;
			case 4:
				System.out.println("Enter Bookid remove book");
				bookid = scanner.nextInt();

				booksBo.delete(bookid);

				break;
			default:
				System.out.println("Invalid choice");
			}

			System.out.println("want to continue");
			choice = scanner.next();
		} while (choice.equals("yes"));

	}
}

