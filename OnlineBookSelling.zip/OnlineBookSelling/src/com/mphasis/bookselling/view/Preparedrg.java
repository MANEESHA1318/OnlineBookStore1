package com.mphasis.bookselling.view;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.mphasis.bookselling.bean.Registration;
import com.mphasis.bookselling.bo.RegistrationBo;

public class Preparedrg {
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		int sno,dob;
		long phonenumber;
		String firstname ,lastname ,emailid ,gender, choice;
		int ch;
		RegistrationBo registrationBo = new RegistrationBo();
		List<Registration> list = new ArrayList<>();
		do {
			System.out.println("CRUD Application");
			System.out.println("1.REGISTER \n 2.READLOGINS \n 3.UPDATEDETAILS \n 4.DELETEACTION");
			System.out.println("Enter choice");
			ch = scanner.nextInt();
		
			switch (ch) {
			case 1:
				System.out.println("Enter Registration sno,firstname,lastname,emailid,phonenumber,gender,dob");
				sno = scanner.nextInt();
				firstname = scanner.next();
			    lastname = scanner.next();
			    emailid = scanner.next();
			    phonenumber = scanner.nextLong();
			    gender = scanner.next();
			    dob = scanner.nextInt();
			    Registration registration = new Registration();
			
				registration.setSno(sno);
				registration.setFirstname(firstname);
				registration.setLastname(lastname);
			    registration.setemailid(emailid);
			    registration.setphonenumber((int) phonenumber);
			    registration.setgender(gender);
			    registration.setdob(dob);
				registrationBo.create(registration);

				break;
			case 2:
				System.out.println("Enter sno");
				sno = scanner.nextInt();

				list = registrationBo.read( sno);
				list.forEach(r -> System.out.println(r));		

				break;

			case 3:
				System.out.println("Enter sno and emailid to update");
				sno = scanner.nextInt();
                emailid=scanner.next();
				registrationBo.update(sno,emailid);

				break;
			case 4:
				System.out.println("Enter sno to delete");
				sno = scanner.nextInt();

				registrationBo.delete(sno);

				break;
			default:
				System.out.println("Invalid choice");
			}

			System.out.println("want to continue");
			choice = scanner.next();
		} while (choice.equals("yes"));

	}
}

