package com.mphasis.bookselling.bean;

public class Books {
   
   private String bookname;
   private int bookid;
   private String author;
   private int price;
   private int quantity;
   private String addtocart;
   
   
   public String getBookname() {
	   return bookname;
   }
   public void setBookname(String bookname) {
	   this.bookname = bookname;
   } 
   public int getBookid() {
	   return bookid;
	   
   }   
   public void setBookid(int bookid) {
	   this.bookid=bookid;
   }
   public String getAuthor() {
	   return author;
   }
   public void setAuthor(String author) {
	   this.author=author;
   }
   public int getPrice() {
	   return price;
   }
   public void setPrice(int price) {
	   this.price=price;
   }
   public int getQuantity() {
	   return quantity;
   }
   public void setQuantity(int quantity) {
	   this.quantity=quantity;
   }
   public String getAddtocart(){
	   return addtocart;
   }
   public void setAddtocart(String addtocart) {
	   this.addtocart=addtocart;
   }
   @Override
	public String toString() {
		return String.format("books [bookname=%s, bookid=%s, author=%s, price=%s, quantity=%s, addtocart=%s]",
				bookname,bookid,author,price,quantity,addtocart);
	}   
   }
