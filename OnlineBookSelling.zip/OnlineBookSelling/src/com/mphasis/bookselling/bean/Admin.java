package com.mphasis.bookselling.bean;

public class Admin {
	private int userid;
	private String username;
	private  int quantity;
	private String status;
	private  String transaction;
	
	public int getUserid() {
		return userid;
	}
public void setUserid(int userid) {
	this.userid=userid;
}
public String getUsername() {
	return username;
	
}
public void setUsername(String username) {
	this.username=username;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity=quantity;
}
public String getStatus() {
	return status;
	
}
public void setStatus(String status) {
	this.status=status;
}
public String getTransaction() {
	return transaction;
}
public void setTransaction(String transaction) {
	this.transaction=transaction;
}
@Override
public String toString() {
	return String.format("admin [userid=%s, username=%s, quantity=%s, status=%s,transaction%s]",
			userid,username,quantity,status,transaction);

}

}