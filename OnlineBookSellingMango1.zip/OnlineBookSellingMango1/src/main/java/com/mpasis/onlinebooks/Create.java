package com.mpasis.onlinebooks;


	import java.util.ArrayList;

	import org.bson.Document;

	import com.mongodb.client.MongoClients;
	import com.mongodb.client.MongoCollection;

	/**
	 * MongoDB Insert Multiple Documents Example
	 * @author Ramesh Fadatare
	 *
	 */
	public class Create {

	    public static void main(String[] args) {

	        try (var mongoClient = MongoClients.create("mongodb://localhost:27017")) {

	            var database = mongoClient.getDatabase("onlinebookstore");

	            var docs = new ArrayList < Document > ();

	            MongoCollection < Document > collection = database.getCollection("Admin");

	            var d1 = new Document("User_id", 1);
	            d1.append("UserName", "Maneesha");
	            d1.append("Status", "Pending");
	            d1.append("transaction"," pending");
	            docs.add(d1);

	            var d2 = new Document("_"
	            		+ "Userid", 2);
	            d2.append("UserName", "Tony");
	            d2.append("Status", "Delevery");
	            d1.append("transaction"," progress");
	            docs.add(d2);

	            var d3 = new Document("Userid", 3);
	            d3.append("UsernameName", "Tom");
	            d3.append("status", "Delevered");
	            d1.append("transaction"," pending");
	            docs.add(d3);


	            collection.insertMany(docs);
	        }
	    }
}
