package com.mpasis.onlinebooks;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoClient;


public class MongoDBApp {
public static void main(String[] args) {
	//MongoClient mongoClient= MongoClients.create();
	//mongoClient.listDatabaseNames();
	//MongoClient mongoClient = new MongoClient( "localhost" , 27017 ); 
	System.out.println("Created Mongo Connection successfully"); 
	//MongoDatabase db = mongoClient.getDatabase("Admin");
	//System.out.println("Get database is successful");
	
	//System.out.println("suceessfuuly connect");
	//MongoClient mongoClient= new MongoClient("localhost",27017);
	 try (var mongoClient = MongoClients.create("mongodb://localhost:27017")) {

         var database = mongoClient.getDatabase("onlinebookstore");

         System.out.println("database name -> " + database.getName());

         for (String name: database.listCollectionNames()) {

             System.out.println(name);
         }
     }
}
	
}
