package com.mpasis.onlinebooks;


	import com.mongodb.client.MongoClients;
	import com.mongodb.client.MongoCollection;
	import com.mongodb.client.MongoCursor;
	import org.bson.Document;

	import java.util.ArrayList;

	/**
	 * MongoDB Read Documents Example
	 * @author Ramesh Fadatare
	 *
	 */

	public class Read {

	    public static void main(String[] args) {

	        try (var mongoClient = MongoClients.create("mongodb://localhost:27017")) {

	            var database = mongoClient.getDatabase("onlinebookstore");

	            MongoCollection < Document > collection = database.getCollection("Admin");

	            try (MongoCursor < Document > cur = collection.find().iterator()) {

	                while (cur.hasNext()) {

	                    var doc = cur.next();
	                    var users = new ArrayList < > (doc.values());

	                    System.out.printf("%s: %s%n", users.get(1), users.get(2));
	                }
	            }
	        }
	    }
	}
